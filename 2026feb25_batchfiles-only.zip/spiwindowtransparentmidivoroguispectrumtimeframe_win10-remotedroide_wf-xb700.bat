rem start spiwindowtransparentmidivoroguispectrumtimeframe.exe "E-MU ASIO" 6 7  "E-MU ASIO" 0 1 1000.0 -1 1920 0 1920 1080 150 0 0 0 24 255 200 0 "spiwindowtransparentclass" "spiwindowtransparenttitle" "" "" "Q49" -1 "" 1 "..\..\spitimeframevisualizervoronoitransparentwin32_vs2013\egypt" ".jpg"
rem start spiwindowtransparentmidivoroguispectrumtimeframe.exe "E-MU ASIO" 6 7  "E-MU ASIO" 2 3 1000.0 -1 1920 0 1920 1080 150 1 0 0 24 255 200 0 "spiwindowtransparentclass" "spiwindowtransparenttitle" "" "" "Q49" -1 "" 1 "..\..\spitimeframevisualizervoronoitransparentwin32_vs2013\face" ".jpg"
rem start spiwindowtransparentmidivoroguispectrumtimeframe.exe "E-MU ASIO" 0 1  "E-MU ASIO" 2 3 1000.0 -1 0 0 1920 1080 150 1 0 0 24 255 200 0 "spiwindowtransparentclass" "spiwindowtransparenttitle" "" "" "Q49" -1 "" 1 "..\..\spitimeframevisualizervoronoitransparentwin32_vs2013\genetic" ".jpg"
rem spiwindowtransparentmidivoroguispectrumtimeframe.exe "E-MU ASIO" 0 1  "E-MU ASIO" 4 5 1000.0 -1 0 0 1920 1080 150 0 0 0 480 255 200 0 "spiwindowtransparentclass" "spiwindowtransparenttitle" "" "" "Q49" -1 "" 1 "..\..\spitimeframevisualizervoronoitransparentwin32_vs2013\dali" ".jpg"
rem start spiwindowtransparentmidivoroguispectrumtimeframe.exe "E-MU ASIO" 0 1  "E-MU ASIO" 4 5 1000.0 -1 0 0 1920 1080 150 0 0 0 24 255 200 0 "spiwindowtransparentclass" "spiwindowtransparenttitle" "" "" "Q49" -1 "" 1 "..\images" ".jpg"
rem start spiwindowtransparentmidivoroguispectrumtimeframe.exe "E-MU ASIO" 0 1  "E-MU ASIO" 4 5 1000.0 -1 0 0 1920 1080 150 0 0 0 96 255 200 0 "spiwindowtransparentclass" "spiwindowtransparenttitle" "" "" "Q49" -1 "" 1 "..\..\spitimeframevisualizervoronoitransparentwin32_vs2013\picasso" ".jpg" 1 1 1 1 1 1
rem start spiwindowtransparentmidivoroguispectrumtimeframe.exe "E-MU ASIO" 0 1  "E-MU ASIO" 4 5 1000.0 -1 0 0 1920 1080 150 0 0 0 96 255 200 0 "spiwindowtransparentclass" "spiwindowtransparenttitle" "" "" "Q49" -1 "" 1 "..\..\spitimeframevisualizervoronoitransparentwin32_vs2013\picasso" ".jpg" 0 0 0 0 0 1
rem start spiwindowtransparentmidivoroguispectrumtimeframe.exe "E-MU ASIO" 0 1  "E-MU ASIO" 4 5 1000.0 -1 0 0 1920 1080 150 0 0 0 24 255 200 0 "spiwindowtransparentclass" "spiwindowtransparenttitle" "" "" "Q49" -1 "" 1 "..\..\spitimeframevisualizervoronoitransparentwin32_vs2013\greek-mythology" ".jpg"
rem start spiwindowtransparentmidivoroguispectrumtimeframe.exe "Microphone (2- Fast Track)" 0 1  "Speakers (2- Fast Track)" 0 1 1000.0 -1 0 0 1920 1080 150 0 0 0 96 255 200 0 "spiwindowtransparentclass" "spiwindowtransparenttitle" "" "" "Q49" -1 "" 1 "..\..\spitimeframevisualizervoronoitransparentwin32_vs2013\picasso" ".jpg" 0 0 0 0 1 0
rem start spiwindowtransparentmidivoroguispectrumtimeframe.exe "Microphone (2- Fast Track)" 0 1  "Speakers (2- Fast Track)" 0 1 1000.0 -1 0 0 1920 1080 150 0 0 0 96 255 200 0 "spiwindowtransparentclass" "spiwindowtransparenttitle" "" "" "Q49" -1 "" 1 "C:\zero-zero-01(scaled-down)(fixed)" ".jpg" 0 0 0 0 1 0
rem start spiwindowtransparentmidivoroguispectrumtimeframe.exe "Microphone (2- Fast Track)" 0 1  "Speakers (2- Fast Track)" 0 1 1000.0 -1 0 0 1920 1080 150 0 0 0 96 255 200 0 "spiwindowtransparentclass" "spiwindowtransparenttitle" "" "" "Q49" -1 "" 1 "C:\zero-zero-01(scaled-down)(fixed)-vorotrans-anim(best-of)" ".jpg" 0 0 0 0 1 0
rem start spiwindowtransparentmidivoroguispectrumtimeframe.exe "Microphone (2- Fast Track)" 0 1  "Speakers (2- Fast Track)" 0 1 1000.0 -1 0 0 1920 1080 150 0 0 0 96 255 200 0 "spiwindowtransparentclass" "spiwindowtransparenttitle" "" "" "Q49" -1 "" 1 "C:\zero-zero-01(scaled-down)(fixed)(nonude)-vorotrans-anim(best-of)" ".jpg" 0 0 0 0 1 0
rem 2020june22 remotedroide spi
rem 
rem [ Default Windows WASAPI Input ]
rem Name = Microphone (Realtek(R) Audio)
rem Host API = Windows WASAPI
rem
rem [ Default Windows WASAPI Output ]
rem Name = 55S425CA (Intel(R) Display Audio)
rem Host API = Windows WASAPI
rem
rem 2021sept20, remotedroide, tested, workes fine
rem black, image and timeframe
rem start spiwindowtransparentmidivoroguispectrumtimeframe.exe "Microphone (Realtek(R) Audio)" 0 1  "55S425CA (Intel(R) Display Audi" 0 1 1000.0 -1 0 0 1920 1080 150 0 0 0 96 255 200 0 "spiwindowtransparentclass" "spiwindowtransparenttitle" "" "" "Q49" -1 "" 1 "D:\temp-3" ".jpg" 1 0 0 0 1 1
rem black and timeframe
rem start spiwindowtransparentmidivoroguispectrumtimeframe.exe "Microphone (Realtek(R) Audio)" 0 1  "55S425CA (Intel(R) Display Audi" 0 1 1000.0 -1 0 0 1920 1080 150 0 0 0 96 255 200 0 "spiwindowtransparentclass" "spiwindowtransparenttitle" "" "" "Q49" -1 "" 1 "D:\temp-3" ".jpg" 1 0 0 0 0 1
rem
rem 2021sept21, remotedroide m-audio m-track duo, note the presence of the space character at the end of "CABLE-A Output (VB-Audio Cable ", it works!
rem "CABLE-A Output (VB-Audio Cable " 0 1 "Speakers (USB AUDIO  CODEC)" 0 1 
rem start spiwindowtransparentmidivoroguispectrumtimeframe.exe "CABLE-A Output (VB-Audio Cable " 0 1 "Speakers (USB AUDIO  CODEC)" 0 1 1000.0 -1 0 0 1920 1080 150 0 0 0 96 255 200 0 "spiwindowtransparentclass" "spiwindowtransparenttitle" "" "" "Q49" -1 "" 1 "..\..\spitimeframevisualizervoronoitransparentwin32_vs2013\greek-mythology" ".jpg" 1 0 0 0 0 1
rem
rem 2021sept21, remotedroide realtek microphone, it works!
rem start spiwindowtransparentmidivoroguispectrumtimeframe.exe "Microphone (Realtek(R) Audio)" 0 1 "Speakers (USB AUDIO  CODEC)" 0 1 1000.0 -1 0 0 1920 1080 150 0 0 0 96 255 200 0 "spiwindowtransparentclass" "spiwindowtransparenttitle" "" "" "Q49" -1 "" 1 "..\..\spitimeframevisualizervoronoitransparentwin32_vs2013\greek-mythology" ".jpg" 1 0 0 0 0 1
rem
set /a global_blackwindowdisplay=0 
set /a global_textwindowdisplay=0
set /a global_spectrumwindowdisplay=0
set /a global_spectrum24bitwindowdisplay=0
set /a global_imagewindowdisplay=1
set /a global_timeframewindowdisplay=0
rem set /a global_spitextwindowdisplay=16
rem set /a global_spitextwindowdisplay=1
set /a global_spitextwindowdisplay=0
rem
rem 2021sept21, remotedroide m-audio m-track duo, note the presence of the space character at the end of "CABLE-A Output (VB-Audio Cable ", it works!
rem saves batches of (gdi) imagewindow frames and creates a video for each
rem for now, doesn't have the code to save batches of (opengl) timeframewindow frames
rem "CABLE-A Output (VB-Audio Cable " 0 1 "Speakers (USB AUDIO  CODEC)" 0 1 
rem start spiwindowtransparentmidivoroguispectrumtimeframe.exe "CABLE-A Output (VB-Audio Cable " 0 1 "Speakers (USB AUDIO  CODEC)" 0 1 1000.0 -1 0 0 1920 1080 150 0 0 0 96 255 200 0 "spiwindowtransparentclass" "spiwindowtransparenttitle" "" "" "Q49" -1 "" 1 "..\..\..\spitimeframevisualizervoronoitransparentwin32_vs2013\greek-mythology" ".jpg" 1 0 0 0 0 1
rem start spiwindowtransparentmidivoroguispectrumtimeframe.exe "CABLE-A Output (VB-Audio Cable " 0 1 "Speakers (USB AUDIO  CODEC)" 0 1 1000.0 -1 0 0 1920 1080 150 0 0 0 96 255 200 0 "spiwindowtransparentclass" "spiwindowtransparenttitle" "" "" "Q49" -1 "" 1 "..\..\..\spitimeframevisualizervoronoitransparentwin32_vs2013-frames-batch\zero-zero-01(scaled-down)_test5" ".jpg" %global_blackwindowdisplay% %global_textwindowdisplay% %global_spectrumwindowdisplay% %global_spectrum24bitwindowdisplay% %global_imagewindowdisplay% %global_timeframewindowdisplay%
rem start spiwindowtransparentmidivoroguispectrumtimeframe.exe "CABLE-A Output (VB-Audio Cable " 0 1 "Speakers (USB AUDIO  CODEC)" 0 1 1000.0 -1 0 0 1920 1080 150 0 0 0 96 255 200 0 "spiwindowtransparentclass" "spiwindowtransparenttitle" "" "" "Q49" -1 "" 1 "..\..\..\spitimeframevisualizervoronoitransparentwin32_vs2013-frames-batch\zero-zero-01(scaled-down)_test2" ".jpg" %global_blackwindowdisplay% %global_textwindowdisplay% %global_spectrumwindowdisplay% %global_spectrum24bitwindowdisplay% %global_imagewindowdisplay% %global_timeframewindowdisplay%
rem start spiwindowtransparentmidivoroguispectrumtimeframe.exe "CABLE-A Output (VB-Audio Cable " 0 1 "Speakers (USB AUDIO  CODEC)" 0 1 1000.0 -1 0 0 1920 1080 150 0 0 0 96 255 200 0 "spiwindowtransparentclass" "spiwindowtransparenttitle" "" "" "Q49" -1 "" 1 "..\..\..\spitimeframevisualizervoronoitransparentwin32_vs2013\greek-mythology" ".jpg" %global_blackwindowdisplay% %global_textwindowdisplay% %global_spectrumwindowdisplay% %global_spectrum24bitwindowdisplay% %global_imagewindowdisplay% %global_timeframewindowdisplay%
rem start spiwindowtransparentmidivoroguispectrumtimeframe.exe "Microphone (Realtek(R) Audio)" 0 1 "Speakers (USB AUDIO  CODEC)" 0 1 1000.0 -1 0 0 1920 1080 150 0 0 0 96 255 200 0 "spiwindowtransparentclass" "spiwindowtransparenttitle" "" "" "Q49" -1 "" 1 "..\..\..\spitimeframevisualizervoronoitransparentwin32_vs2013\greek-mythology" ".jpg" 1 0 0 0 0 1
rem start spiwindowtransparentmidivoroguispectrumtimeframe.exe "Microphone (Realtek(R) Audio)" 0 1 "Speakers (USB AUDIO  CODEC)" 0 1 1000.0 -1 0 0 1920 1080 150 0 0 0 96 255 200 0 "spiwindowtransparentclass" "spiwindowtransparenttitle" "" "" "Q49" -1 "" 1 "..\..\..\spitimeframevisualizervoronoitransparentwin32_vs2013\picasso" ".jpg" %global_blackwindowdisplay% %global_textwindowdisplay% %global_spectrumwindowdisplay% %global_spectrum24bitwindowdisplay% %global_imagewindowdisplay% %global_timeframewindowdisplay%
rem start spiwindowtransparentmidivoroguispectrumtimeframe.exe "CABLE-A Output (VB-Audio Cable " 0 1 "Speakers (USB AUDIO  CODEC)" 0 1 1000.0 -1 0 0 1920 1080 150 0 0 0 96 255 200 0 "spiwindowtransparentclass" "spiwindowtransparenttitle" "" "" "Q49" -1 "" 1 "..\..\..\spitimeframevisualizervoronoitransparentwin32_vs2013\picasso" ".jpg" %global_blackwindowdisplay% %global_textwindowdisplay% %global_spectrumwindowdisplay% %global_spectrum24bitwindowdisplay% %global_imagewindowdisplay% %global_timeframewindowdisplay%
rem echo spiwindowtransparentmidivoroguispectrumtimeframe.exe "CABLE-A Output (VB-Audio Cable " 0 1 "Speakers (USB AUDIO  CODEC)" 0 1 1000.0 -1 0 0 1920 1080 150 0 0 0 96 255 200 0 "spiwindowtransparentclass" "spiwindowtransparenttitle" "" "" "Q49" -1 "" 1 "..\..\..\spitimeframevisualizervoronoitransparentwin32_vs2013\picasso" ".jpg" %global_blackwindowdisplay% %global_textwindowdisplay% %global_spectrumwindowdisplay% %global_spectrum24bitwindowdisplay% %global_imagewindowdisplay% %global_timeframewindowdisplay% > spiwindowtransparentmidivoroguispectrumtimeframe.txt
rem
rem 2021nov29, lot of fresh code
rem 2021dec24, lot of fresh code
set global_audioinputdevicename="CABLE-A Output (VB-Audio Cable "
rem set global_audiooutputdevicename="Speakers (USB AUDIO  CODEC)"
rem bluetooth tp 18 headphones, "Output (@System32\drivers\bthhfenum.sys,#4;%1 Hands-Free HF Audio%0"
rem set global_audiooutputdevicename="Output (@System32\drivers\bthhfenum.sys,#4;%1 Hands-Free HF Audio%0"
rem 2022nov14, works
rem set global_audiooutputdevicename="MME:Headphones (TP 18 Stereo)"
rem set global_audiooutputdevicename="Speakers (USB AUDIO  CODEC)"
rem 2022dec24, does not works
rem set global_audiooutputdevicename="WASAPI:Headset (TP 18 Hands-Free AG Audio)"
rem 2022dec24, works
rem set global_audiooutputdevicename="MME:TP 18 Stereo"
rem 2023jan09, sony ear bud
set global_audiooutputdevicename="WF-XB700"
rem set global_inputmididevicename="Q49"
set global_inputmididevicename=""
set global_inputmidichannel="-1"
set global_outputmididevicename=""
set global_outputmidichannel="1"
rem set global_modestring="VOROGUICLUSTER,DEBUG,SPITEXT"
rem set global_modestring="VOROGUICLUSTER,VOROGUIDBG,SPITEXT"
rem set global_modestring="VOROGUICLUSTER,SPITEXT"
rem set global_modestring="VOROGUICLUSTER,VOROGUIGRIDLIKE,SPITEXT"
rem set global_modestring="VOROGUICLUSTER,DEBUG,VOROGUIGRIDLIKE,SPITEXT"
rem set global_modestring="VOROGUICLUSTER"
rem set global_modestring="VOROGUICLUSTER,VOROGUIGRIDLIKE,VOROGUIRANDOMIZED,SPITEXT"
rem set global_modestring="VOROGUICLUSTER,VOROGUILISTLIKE,SPITEXT"
rem set global_modestring="VOROGUICLUSTER,VOROGUILISTLIKE,VOROGUIRANDOMIZED,SPITEXT"
rem set global_modestring="VOROGUICLUSTER,VOROGUILISTLIKE,VOROGUIVERTICAL,SPITEXT"
rem set global_modestring="VOROGUICLUSTER,VOROGUILISTLIKE,VOROGUIVERTICAL,VOROGUIRANDOMIZED,SPITEXT"
rem set global_modestring="VOROGUICLUSTER,VOROGUILISTLIKE,VOROGUIHORIZONTAL,SPITEXT"
rem set global_modestring="VOROGUICLUSTER,VOROGUILISTLIKE,VOROGUIHORIZONTAL,VOROGUIRANDOMIZED,SPITEXT"
set global_modestring="VOROGUICLUSTER,SPITEXT"
rem set global_modestring="SPITEXT"
rem set global_modestring="VOROGUICLUSTER,VOROGUIGRIDLIKE,DEBUG,SPITEXT"
rem 2022dec24, works
rem set global_modestring="VOROGUICLUSTER,SPITEXT"
rem set global_imagepaths="D:\spicode\audio_spi\spiregeneratemediafoldersinfo_vs2017\x64\Release\2022nov18_spi-images_all-blue-filenames_remotedroide.txt"
rem set global_imagepaths="D:\spicode\audio_spi\spiregeneratemediafoldersinfo_vs2017\x64\Release\2021oct12_spi-images-novoro-noseed_all-yellow-filenames_remotedroide.txt"
rem set global_imagepaths="D:\spicode\audio_spi\spiregeneratemediafoldersinfo_vs2017\x64\Release\2021oct12_spi-images-nozero_all-red-filenames_remotedroide.txt"
rem set global_imagepaths="D:\spicode\audio_spi\spiregeneratemediafoldersinfo_vs2017\x64\Release\2021oct12_spi-images-noseed-nozero_all-purple-filenames_remotedroide.txt"
rem set global_imagepaths="D:\spicode\audio_spi\spiregeneratemediafoldersinfo_vs2017\x64\Release\2021oct12_spi-images-noseed-nozero_all-orange-filenames_remotedroide.txt"
rem set global_imagepaths="D:\spicode\audio_spi\spiregeneratemediafoldersinfo_vs2017\x64\Release\2021oct12_spi-images-noseed-nozero_all-green-filenames_remotedroide.txt"
rem set global_imagepaths="D:\spicode\audio_spi\spiregeneratemediafoldersinfo_vs2017\x64\Release\2021oct12_spi-images-noseed_all-bluedark-filenames_remotedroide.txt"
rem set global_imagepaths="D:\spicode\audio_spi\spiregeneratemediafoldersinfo_vs2017\x64\Release\2021oct12_spi-images-noseedlegit_all-othercolors-filenames_remotedroide.txt"
rem set global_imagepaths="D:\spicode\audio_spi\spiregeneratemediafoldersinfo_vs2017\x64\Release\2021oct12_spi-images-noseed_all-pink-filenames_remotedroide.txt"
rem set global_imagepaths="D:\spicode\audio_spi\spiregeneratemediafoldersinfo_vs2017\x64\Release\2021oct12_spi-images-zero_all-yellow-filenames_remotedroide.txt"
rem set global_imagepaths="D:\spicode\audio_spi\spiregeneratemediafoldersinfo_vs2017\x64\Release\2021oct12_spi-images-zero_all-white-filenames_remotedroide.txt"
rem
rem 2022nov18, fresh media classification
rem set global_imagepaths="D:\spicode\audio_spi\spiregeneratemediafoldersinfo_vs2017\x64\Release\2022nov18_spi-images-noseed-nozero_all-orange-filenames_remotedroide.txt"
rem set global_imagepaths="D:\spicode\audio_spi\spiregeneratemediafoldersinfo_vs2017\x64\Release\2022nov18_spi-images-voro-zero_all-bluedark-filenames_remotedroide.txt"
rem set global_imagepaths="D:\spicode\audio_spi\spiregeneratemediafoldersinfo_vs2017\x64\Release\2022nov18_spi-images-voro-zero_all-yellow-filenames_remotedroide.txt"
rem set global_imagepaths="D:\spicode\audio_spi\spiregeneratemediafoldersinfo_vs2017\x64\Release\2022nov18_spi-images-voro-zero_all-black-filenames_remotedroide.txt"
rem set global_imagepaths="D:\spicode\audio_spi\spiregeneratemediafoldersinfo_vs2017\x64\Release\2022nov18_spi-images-zero_all-blue-filenames_remotedroide.txt"
rem set global_imagepaths="D:\spicode\audio_spi\spiregeneratemediafoldersinfo_vs2017\x64\Release\2022nov18_spi-images-noseed_all-pink-filenames_remotedroide.txt"
rem set global_imagepaths="D:\spicode\audio_spi\spiregeneratemediafoldersinfo_vs2017\x64\Release\2022nov18_spi-images-zero_all-yellow-filenames_remotedroide.txt"
rem set global_imagepaths="D:\spicode\audio_spi\spiregeneratemediafoldersinfo_vs2017\x64\Release\2022nov18_spi-images-novoro-noseed_all-yellow-filenames_remotedroide.txt"
rem set global_imagepaths="D:\spicode\audio_spi\spiregeneratemediafoldersinfo_vs2017\x64\Release\2022nov18_spi-images-zero_all-white-filenames_remotedroide.txt"
rem set global_imagepaths="D:\spicode\audio_spi\spiregeneratemediafoldersinfo_vs2017\x64\Release\2022nov18_spi-images_all-black-filenames_remotedroide.txt"
rem set global_imagepaths="D:\spicode\audio_spi\spiregeneratemediafoldersinfo_vs2017\x64\Release\2022nov18_spi-images-nozero_all-white-filenames_remotedroide.txt"
rem set global_imagepaths="D:\spicode\audio_spi\spiregeneratemediafoldersinfo_vs2017\x64\Release\2022nov18_spi-images_all-bluedark-filenames_remotedroide.txt"
rem set global_imagepaths="D:\spicode\audio_spi\spiregeneratemediafoldersinfo_vs2017\x64\Release\2022nov18_spi-images_all-yellow-filenames_remotedroide.txt"
rem set global_imagepaths="D:\spicode\audio_spi\spiregeneratemediafoldersinfo_vs2017\x64\Release\2022nov18_spi-images_all-white-filenames_remotedroide.txt"
rem set global_imagepaths="D:\spicode\audio_spi\spiregeneratemediafoldersinfo_vs2017\x64\Release\2022nov18_spi-images_all-othercolors-filenames_remotedroide.txt"
rem set global_imagepaths="D:\spicode\audio_spi\spiregeneratemediafoldersinfo_vs2017\x64\Release\2022nov18_spi-images-noseed_all-black-filenames_remotedroide.txt"
rem set global_imagepaths="D:\spicode\audio_spi\spiregeneratemediafoldersinfo_vs2017\x64\Release\2022nov18_spi-images-noseed_all-pink-filenames_remotedroide.txt"
rem set global_imagepaths="D:\spicode\audio_spi\spiregeneratemediafoldersinfo_vs2017\x64\Release\2022nov18_spi-images-novoro-nozero-noseed_all-4k-filenames_remotedroide.txt"
rem set global_imagepaths="D:\video\dali-cc(ultra-vivid)(set12)\underworld-rez_3sec(depth3xycoor-in-zoomwindows-txt-)(slow)(ip1)(nq0)(icp30-0000)(pq75-0000)(ot0-0010)(oi2-0000)(note)(cf240)"
set global_imagepaths="D:\video\rocher-perce-cc"
rem
rem 2022dec22, visually safe media
rem set global_imagepaths="D:\spicode\audio_spi\spiwindowtransparentmidivoroguispectrumtimeframe_vs2017_frames-batch\greek-mythology"
rem set global_imagepaths="D:\spicode\audio_spi\spiwindowtransparentmidivoroguispectrumtimeframe_vs2017_frames-batch\picasso"
rem
start spiwindowtransparentmidivoroguispectrumtimeframe.exe %global_audioinputdevicename% 0 1 %global_audiooutputdevicename% 0 1 1000.0 -1 0 0 1920 1080 150 0 0 0 96 255 200 0 "spiwindowtransparentclass" "spiwindowtransparenttitle" "" "" %global_inputmididevicename% %global_inputmidichannel% %global_outputmididevicename% %global_outputmidichannel% %global_imagepaths% ".jpg" %global_blackwindowdisplay% %global_textwindowdisplay% %global_spectrumwindowdisplay% %global_spectrum24bitwindowdisplay% %global_imagewindowdisplay% %global_timeframewindowdisplay% %global_spitextwindowdisplay% %global_modestring%
echo spiwindowtransparentmidivoroguispectrumtimeframe.exe %global_audioinputdevicename% 0 1 %global_audiooutputdevicename% 0 1 1000.0 -1 0 0 1920 1080 150 0 0 0 96 255 200 0 "spiwindowtransparentclass" "spiwindowtransparenttitle" "" "" %global_inputmididevicename% %global_inputmidichannel% %global_outputmididevicename% %global_outputmidichannel% %global_imagepaths% ".jpg" %global_blackwindowdisplay% %global_textwindowdisplay% %global_spectrumwindowdisplay% %global_spectrum24bitwindowdisplay% %global_imagewindowdisplay% %global_timeframewindowdisplay% %global_spitextwindowdisplay% %global_modestring% > spiwindowtransparentmidivoroguispectrumtimeframe_win10-remotedroide.txt
