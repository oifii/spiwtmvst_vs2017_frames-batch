rem echo off
rem oifiilib-dlls_getcopy_call-from-src-folder.bat
set pathinitdir=%CD%
cd ..\..
call oifiilib-dlls_getcopy.bat
start notepad.exe oifiilib-dlls_getcopy_output.txt
cd %pathinitdir%
